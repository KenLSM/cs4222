## HW1
### Members
#### Ken Lee Shu Ming
- A0125546E
- Sensortag Node ID: broken :'(

#### Hon Guang Yu Jeremy
- A0127572A
- Sensortag Node ID: 22791