#define PROJECT_CONF_H_
#define RF_CORE_CONF_CHANNEL 					11
#define NETSTACK_CONF_RDC_CHANNEL_CHECK_RATE 	32
#define NETSTACK_NETWORK 						rime_driver
#define NETSTACK_CONF_MAC 						nullmac_driver
#define NETSTACK_CONF_RDC 						contikimac_driver
#define NETSTACK_CONF_FRAMER 					framer_802154